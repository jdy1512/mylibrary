# Vert.x module sample #

This project is an archetype for a Vert'x module.

You can make any runnable or non-runnable module from this.

## Resources

[Modules Manual](http://vertx.io/mods_manual.html)
