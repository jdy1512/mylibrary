﻿using UnityEngine;
using System.Collections;

public class DestroyBullet : MonoBehaviour {

	void OnCollisionEnter ( Collision coll )
	{
		if ( coll.gameObject.tag == "BULLET")
		{
			Destroy ( coll.gameObject );
			//Destroy ( gameObject );
			//Destroy ( this.gameObject );
			//Destroy ( this );
		}
	}

}
