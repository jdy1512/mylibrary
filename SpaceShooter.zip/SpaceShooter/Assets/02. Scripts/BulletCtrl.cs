﻿using UnityEngine;
using System.Collections;

public class BulletCtrl : MonoBehaviour {
	public float speed = 300.0f;
	
	void Start () {
		//rigidbody.AddForce ( transform.forward * speed );	
		rigidbody.AddRelativeForce ( Vector3.forward * speed);
	}

}
