﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class Anims
{
	public AnimationClip idle;
	public AnimationClip runForward;
	public AnimationClip runBackward;
	public AnimationClip runRight;
	public AnimationClip runLeft;
	public AnimationClip[] dies;
}

public class PlayerCtrl : MonoBehaviour {

	public Anims anims;

	[HideInInspector]
	public Animation _animation;

	[Range(5.0f, 10.0f)]
	public float moveSpeed = 10.0f;

	private Transform tr;
	
	void Start () {
		tr = GetComponent<Transform>();
		_animation = GetComponentInChildren<Animation>();

		/*
		tr = GetComponent("Transform") as Transform;
		tr = (Transform) GetComponent("Transform");
		*/
	}
	
	// Update is called once per frame
	void Update () {
		float h = Input.GetAxis ("Horizontal");
		float v = Input.GetAxis ("Vertical");

		//Debug.Log ( "h=" + h );
		//Debug.Log ( "v=" + v );

		Vector3 moveDir = (Vector3.forward * v) + (Vector3.right * h);
		tr.Translate ( moveDir.normalized * moveSpeed * Time.deltaTime );
		tr.Rotate ( Vector3.up * 100.0f * Time.deltaTime * Input.GetAxis ("Mouse X") );

		if ( v >= 0.1f ){
			_animation.CrossFade ( anims.runForward.name , 0.3f );
		}else if ( v <= -0.1f ){
			_animation.CrossFade ( anims.runBackward.name, 0.3f );
		}else if ( h >= 0.1f ){
			_animation.CrossFade ( anims.runRight.name, 0.3f );
		}else if ( h <= -0.1f ){
			_animation.CrossFade ( anims.runLeft.name, 0.3f );
		}else {
			_animation.CrossFade ( anims.idle.name, 0.3f );
		}


	}

} //End


