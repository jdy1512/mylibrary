﻿using UnityEngine;
using System.Collections;

public class FireBullet : MonoBehaviour {

	public GameObject bullet;
	public Transform firePos;

	// Use this for initialization
	void Start () {
	
	}

	void Update () {
		if ( Input.GetMouseButtonDown (0))
		{
			Fire ();
		}
	}

	void Fire()
	{
		StartCoroutine ( this.CreateBullet() );
	}

	IEnumerator CreateBullet()
	{
		Instantiate ( bullet, firePos.position, firePos.rotation );
		yield return null;

		Debug.Log ("finish");
	}






}
